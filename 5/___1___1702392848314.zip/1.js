export function Welcome({ name = 'World' }) {
	return <p>Hello, {name}!</p>
}
