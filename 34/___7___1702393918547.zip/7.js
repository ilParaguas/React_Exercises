// Docs for react-bootstrap are here: https://react-bootstrap.github.io/

// Install the package, then import a component from it:
// import { Button } from 'react-bootstrap'

// You can then use it in place of regular <buttons> in your app:
// <Button variant="primary">Increment Counter</Button>

// See the docs for customization options
