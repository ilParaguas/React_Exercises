import { Hello } from './1'
import { Message } from './2'

export function App() {
	return (
		<div>
			<Hello />
			<Hello />
			<Message />
		</div>
	)
}
