// Install tailwindcss by following the instructions at: https://tailwindcss.com/docs/guides/create-react-app
// After installing, play around with the classes by reading the documentation
